<?php
/**
 * Plugin Name: Furgan Toolkit
 * Plugin URI: https://dreamingtheme.great-site.net/
 * Description: The Furgan Toolkit For WordPress Theme WooCommerce Shop.
 * Author: Dreamingtheme
 * Author URI: https://dreamingtheme.great-site.net/
 * Version: 1.0.5
 * Text Domain: furgan-toolkit
 */
// Exit if accessed directly.
if ( !defined( 'ABSPATH' ) ) exit;
if ( !class_exists( 'Furgan_Toolkit' ) ) {
	class  Furgan_Toolkit
	{
        
		private static $instance;

		public static function instance()
		{
			if ( !isset( self::$instance ) && !( self::$instance instanceof Furgan_Toolkit ) ) {
				self::$instance = new Furgan_Toolkit;
				self::$instance->setup_constants();
                add_action( 'init', array( self::$instance, 'load_textdomain' ) );
				self::$instance->includes();
				add_action( 'after_setup_theme', array( self::$instance, 'after_setup_theme' ) );
                add_action('upload_mimes', array(self::$instance, 'furgan_toolkit_add_file_types_to_uploads'));
			}

			return self::$instance;
		}

		public function after_setup_theme()
		{
			require_once FURGAN_TOOLKIT_PATH . 'includes/admin/live-search/live-search.php';
			require_once FURGAN_TOOLKIT_PATH . 'includes/mapper/addon.php';
			require_once FURGAN_TOOLKIT_PATH . 'includes/footer-builder/footer-builder.php';
			require_once FURGAN_TOOLKIT_PATH . 'includes/megamenu/megamenu.php';
            if ( class_exists( 'WooCommerce' ) ) {
                require_once FURGAN_TOOLKIT_PATH . 'includes/dreaming-woocommerce-compare/dreaming-woocommerce-compare.php';
            }
		}

		public function setup_constants()
		{
			// Plugin version.
			if ( !defined( 'FURGAN_TOOLKIT_VERSION' ) ) {
				define( 'FURGAN_TOOLKIT_VERSION', '1.0.4' );
			}
			// Plugin Folder Path.
			if ( !defined( 'FURGAN_TOOLKIT_PATH' ) ) {
				define( 'FURGAN_TOOLKIT_PATH', plugin_dir_path( __FILE__ ) );
			}
			// Plugin Folder URL.
			if ( !defined( 'FURGAN_TOOLKIT_URL' ) ) {
				define( 'FURGAN_TOOLKIT_URL', plugin_dir_url( __FILE__ ) );
			}
		}

		public function includes()
		{
			require_once FURGAN_TOOLKIT_PATH . 'includes/admin/welcome.php';
			require_once FURGAN_TOOLKIT_PATH . 'includes/frontend/framework.php';
		}

		public function load_textdomain()
		{
			load_plugin_textdomain( 'furgan-toolkit', false, FURGAN_TOOLKIT_URL . 'languages' );
		}

        function furgan_toolkit_add_file_types_to_uploads($file_types)
        {
            $new_filetypes = array();
            $new_filetypes['svg'] = 'image/svg+xml';
            $file_types = array_merge($file_types, $new_filetypes);

            return $file_types;
        }

        public $default = array(
            'footer'           => true,
            'megamenu'         => true,
            'mobile'           => true,
            'crop'             => false,
            'fa4_support'      => false,
            'placeholder'      => '',
            'fontawesome'      => 'fa4',
            'mobile_delay'     => 0,
            'mobile_menu'      => 'click',
            'clear_cache'      => '',
            'megamenu_resize'  => 'tablet',
        );
        public static function get_config($key = '', $default = false)
        {
            $args   = array(
                'fa4_support' => false,
                'fontawesome' => 'fa4',
            );
            $key    = trim($key);
            $config = get_option('furgan_addon_settings');
            $config = wp_parse_args($config, $args);

            if (empty($key)) {
                return $config;
            }

            if (!empty($config[$key])) {
                return $config[$key];
            }

            return $default;
        }
        public function is_request($type)
        {
            switch ($type) {
                case 'admin':
                    return is_admin();
                case 'ajax':
                    return function_exists('wp_doing_ajax') ? wp_doing_ajax() : defined('DOING_AJAX');
                case 'cron':
                    return defined('DOING_CRON');
                case 'frontend':
                    return !is_admin() && !defined('DOING_CRON');
                default:
                    return false;
            }
        }
        /**
         * What is support elementor or not?
         *
         * @param  string  $type  post_type or id.
         *
         * @return bool
         */
        public function is_support_elementor($type)
        {
            $post_type   = is_numeric($type) ? get_post_type($type) : $type;
            $cpt_support = get_option('elementor_cpt_support', ['page', 'post']);

            if (class_exists('Elementor\Plugin') && in_array($post_type, $cpt_support)) {
                return true;
            }

            return false;
        }

        /**
         * What is elementor or not?
         *
         * @param  int  $post_id  post_type or id.
         *
         * @return bool
         */
        public function is_elementor($post_id)
        {
            if (class_exists('Elementor\Plugin') && $this->is_support_elementor($post_id)) {
                if (get_post_meta($post_id, '_elementor_edit_mode', true)) {
                    return true;
                }
            }

            return false;
        }

        /**
         * is WPBackery editor?
         *
         * @return bool
         */
        public function is_vc_editor()
        {
            return false;
        }

        /**
         * is Elementor editor?
         *
         * @return bool
         */
        public function is_elementor_editor()
        {
            if (class_exists('Elementor\Plugin')) {
                if (Elementor\Plugin::$instance->preview->is_preview_mode() || Elementor\Plugin::$instance->editor->is_edit_mode()) {
                    return true;
                }
            }

            return false;
        }
	}
}
if ( !function_exists( 'FURGAN_TOOLKIT' ) ) {
	function FURGAN_TOOLKIT()
	{
		return Furgan_Toolkit::instance();
	}

	FURGAN_TOOLKIT();
	add_action( 'plugins_loaded', 'FURGAN_TOOLKIT', 10 );
}