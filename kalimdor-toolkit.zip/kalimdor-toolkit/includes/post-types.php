<?php
/**
 * @version    1.0
 * @package    Kalimdor_Toolkit
 * @author     Kalimdor
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 */
/**
 * Class Toolkit Post Type
 *
 * @since    1.0
 */
if ( !class_exists( 'Kalimdor_Post_Type' ) ) {
	class Kalimdor_Post_Type
	{
		public function __construct()
		{
			add_action( 'init', array( &$this, 'init' ), 9999 );
		}

		public static function init()
		{
			/* Mega menu */
			$args = array(
				'labels'              => array(
					'name'               => __( 'Mega Builder', 'kalimdor-toolkit' ),
					'singular_name'      => __( 'Mega menu item', 'kalimdor-toolkit' ),
					'add_new'            => __( 'Add new', 'kalimdor-toolkit' ),
					'add_new_item'       => __( 'Add new menu item', 'kalimdor-toolkit' ),
					'edit_item'          => __( 'Edit menu item', 'kalimdor-toolkit' ),
					'new_item'           => __( 'New menu item', 'kalimdor-toolkit' ),
					'view_item'          => __( 'View menu item', 'kalimdor-toolkit' ),
					'search_items'       => __( 'Search menu items', 'kalimdor-toolkit' ),
					'not_found'          => __( 'No menu items found', 'kalimdor-toolkit' ),
					'not_found_in_trash' => __( 'No menu items found in trash', 'kalimdor-toolkit' ),
					'parent_item_colon'  => __( 'Parent menu item:', 'kalimdor-toolkit' ),
					'menu_name'          => __( 'Menu Builder', 'kalimdor-toolkit' ),
				),
				'hierarchical'        => false,
				'description'         => __( 'Mega Menus.', 'kalimdor-toolkit' ),
				'supports'            => array( 'title', 'editor' ),
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => 'kalimdor_menu',
				'menu_position'       => 3,
				'show_in_nav_menus'   => true,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'has_archive'         => false,
				'query_var'           => true,
				'can_export'          => true,
				'rewrite'             => false,
				'capability_type'     => 'page',
				'menu_icon'           => 'dashicons-welcome-widgets-menus',
			);
			register_post_type( 'megamenu', $args );
			/* Footer */
			$args = array(
				'labels'              => array(
					'name'               => __( 'Footers', 'kalimdor-toolkit' ),
					'singular_name'      => __( 'Footers', 'kalimdor-toolkit' ),
					'add_new'            => __( 'Add New', 'kalimdor-toolkit' ),
					'add_new_item'       => __( 'Add new footer', 'kalimdor-toolkit' ),
					'edit_item'          => __( 'Edit footer', 'kalimdor-toolkit' ),
					'new_item'           => __( 'New footer', 'kalimdor-toolkit' ),
					'view_item'          => __( 'View footer', 'kalimdor-toolkit' ),
					'search_items'       => __( 'Search template footer', 'kalimdor-toolkit' ),
					'not_found'          => __( 'No template items found', 'kalimdor-toolkit' ),
					'not_found_in_trash' => __( 'No template items found in trash', 'kalimdor-toolkit' ),
					'parent_item_colon'  => __( 'Parent template item:', 'kalimdor-toolkit' ),
					'menu_name'          => __( 'Footer Builder', 'kalimdor-toolkit' ),
				),
				'hierarchical'        => false,
				'description'         => __( 'To Build Template Footer.', 'kalimdor-toolkit' ),
				'supports'            => array( 'title', 'editor' ),
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => 'kalimdor_menu',
				'menu_position'       => 4,
				'show_in_nav_menus'   => true,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'has_archive'         => false,
				'query_var'           => true,
				'can_export'          => true,
				'rewrite'             => false,
				'capability_type'     => 'page',
			);
			register_post_type( 'footer', $args );
		}
	}

	new Kalimdor_Post_Type();
}
