<?php
if (!defined('ABSPATH')) {
    exit;
}
/**
 * Kalimdor Mailchimp
 *
 * Displays Mailchimp widget.
 *
 * @category Widgets
 * @package  Kalimdor/Widgets
 * @version  1.0.0
 * @extends  KALIMDOR_Widget
 */
if (!class_exists('Kalimdor_Mailchimp_Widget')) {
    class Kalimdor_Mailchimp_Widget extends KALIMDOR_Widget
    {
        /**
         * Constructor.
         */
        public function __construct()
        {
            $list_form = array();
            $list_form[0] = esc_html__('Select a form','kalimdor-toolkit');
            if (function_exists('mc4wp_show_form')) {
                $args  = array(
                    'posts_per_page' => -1,
                    'post_type'      => 'mc4wp-form',
                    'post_status'    => 'publish',
                    'fields'         => 'ids',
                );
                $posts = get_posts($args);
                if ($posts) {
                    foreach ($posts as $post_id) {
                        $post_id             = intval($post_id);
                        $title               = get_the_title($post_id);
                        $list_form[$post_id] = $title;
                    }
                }
            }
            $array_settings = apply_filters('kalimdor_filter_settings_widget_mailchimp',
                array(
                    'title' => array(
                        'type' => 'text',
                        'title' => esc_html__('Title', 'kalimdor-toolkit'),
                    ),
                    'description' => array(
                        'type' => 'text',
                        'title' => esc_html__('Description:', 'kalimdor-toolkit'),
                        'default' => esc_html__('To stay up-to-date on our promotions, discounts, sales and more', 'kalimdor-toolkit'),
                    ),
                    'id' => array(
                        'type' => 'select',
                        'options' => $list_form,
                        'title' => esc_html__('Newsletter Form', 'kalimdor-toolkit'),
                        'default' => '0',
                    ),
                )
            );
            $this->widget_cssclass = 'widget-kalimdor-mailchimp';
            $this->widget_description = esc_html__('Display the customer Newsletter.', 'kalimdor-toolkit');
            $this->widget_id = 'widget_kalimdor_mailchimp';
            $this->widget_name = esc_html__('Kalimdor: Newsletter', 'kalimdor-toolkit');
            $this->settings = $array_settings;
            parent::__construct();
        }

        /**
         * Output widget.
         *
         * @see WP_Widget
         *
         * @param array $args
         * @param array $instance
         */
        public function widget($args, $instance)
        {
            $this->widget_start($args, $instance);
            ob_start();
            ?>
            <div class="newsletter-form-wrap">
                <div class="desc"><?php echo esc_html($instance['description']); ?></div>
                <div class="form-newsletter">
                    <?php
                    if (function_exists('mc4wp_show_form')) {
                        mc4wp_show_form($instance['id']);
                    }
                    ?>
                </div>
            </div>
            <?php
            echo apply_filters('kalimdor_filter_widget_newsletter', ob_get_clean(), $instance);
            $this->widget_end($args);
        }
    }
}
add_action('widgets_init', 'Kalimdor_Mailchimp_Widget');
if (!function_exists('Kalimdor_Mailchimp_Widget')) {
    function Kalimdor_Mailchimp_Widget()
    {
        register_widget('Kalimdor_Mailchimp_Widget');
    }
}