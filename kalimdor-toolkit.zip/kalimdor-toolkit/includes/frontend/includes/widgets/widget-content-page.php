<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Kalimdor Content Page
 *
 * Displays Content Page widget.
 *
 * @category Widgets
 * @package  Kalimdor/Widgets
 * @version  1.0.0
 * @extends  KALIMDOR_Widget
 */
if ( !class_exists( 'Kalimdor_Content_Page_Widget' ) ) {
	class Kalimdor_Content_Page_Widget extends KALIMDOR_Widget
	{
		/**
		 * Constructor.
		 */
		public function __construct()
		{
			$array_settings           = apply_filters( 'kalimdor_filter_settings_widget_content_page',
				array(
					'title'         => array(
						'type'  => 'text',
						'title' => esc_html__( 'Title', 'kalimdor-toolkit' ),
					),
					'kalimdor_page_id' => array(
						'type'    => 'select',
						'title'   => esc_html__( 'Select Content', 'kalimdor-toolkit' ),
						'options' => 'pages',
					),
				)
			);
			$this->widget_cssclass    = 'widget-kalimdor-content_page kalimdor-content_page';
			$this->widget_description = esc_html__( 'Display the customer Content Page.', 'kalimdor-toolkit' );
			$this->widget_id          = 'widget_kalimdor_content_page';
			$this->widget_name        = esc_html__( 'Kalimdor: Content Page', 'kalimdor-toolkit' );
			$this->settings           = $array_settings;
			parent::__construct();
		}

		/**
		 * Output widget.
		 *
		 * @see WP_Widget
		 *
		 * @param array $args
		 * @param array $instance
		 */
		public function widget( $args, $instance )
		{
			$this->widget_start( $args, $instance );
			if ( $instance['kalimdor_page_id'] ) {
				$post_id = get_post( $instance['kalimdor_page_id'] );
				$content = $post_id->post_content;
				$content = apply_filters( 'the_content', $content );
				$content = str_replace( ']]>', ']]>', $content );
				/* GET CUSTOM CSS */
				$post_custom_css = get_post_meta( $instance['kalimdor_page_id'], '_Kalimdor_Shortcode_custom_css', true );
				echo '<style type="text/css">' . $post_custom_css . '</style>';
				echo $content;
			}
			$this->widget_end( $args );
		}
	}
}
/**
 * Register Widgets.
 *
 * @since 2.3.0
 */
function Kalimdor_Content_Page_Widget()
{
	register_widget( 'Kalimdor_Content_Page_Widget' );
}

add_action( 'widgets_init', 'Kalimdor_Content_Page_Widget' );