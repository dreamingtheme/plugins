<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'Kalimdor_Pinmap_Builder' ) ) {
	class  Kalimdor_Pinmap_Builder
	{
		/**
		 * @var Kalimdor_Pinmap_Builder The one true Kalimdor_Pinmap_Builder
		 */
		private static $instance;

		public static function instance()
		{
			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Kalimdor_Pinmap_Builder ) ) {
				self::$instance = new Kalimdor_Pinmap_Builder;
				self::$instance->includes();
				/* Add image size for woocommerce product */
				$size_thumb = apply_filters( 'kalimdor_pinmap_product_thumbnail', array(
						'width'  => 100,
						'height' => 150,
						'crop'   => true
					)
				);
				add_image_size( 'kalimdor-pinmap-thumbnail', $size_thumb['width'], $size_thumb['height'], $size_thumb['crop'] );
			}

			return self::$instance;
		}

		public function includes()
		{
			require_once KALIMDOR_TOOLKIT_PATH . 'includes/mapper/includes/post-type.php';
			require_once KALIMDOR_TOOLKIT_PATH . 'includes/mapper/includes/shortcode.php';
		}
	}
}
if ( ! function_exists( 'Kalimdor_Pinmap_Builder' ) ) {
	function Kalimdor_Pinmap_Builder()
	{
		return Kalimdor_Pinmap_Builder::instance();
	}
}
Kalimdor_Pinmap_Builder();