<?php
/**
 * Plugin Name: Kalimdor Toolkit
 * Plugin URI: https://marytinc.com/
 * Description: The Kalimdor Toolkit For WordPress Theme WooCommerce Shop.
 * Author: Dreamingtheme
 * Author URI: https://marytinc.com/
 * Version: 1.1.1
 * Text Domain: kalimdor-toolkit
 */
// Exit if accessed directly.
if ( !defined( 'ABSPATH' ) ) exit;
if ( !class_exists( 'Kalimdor_Toolkit' ) ) {
	class  Kalimdor_Toolkit
	{
		/**
		 * @var Kalimdor_Toolkit The one true Kalimdor_Toolkit
		 * @since 1.0
		 */
		private static $instance;

		public static function instance()
		{
			if ( !isset( self::$instance ) && !( self::$instance instanceof Kalimdor_Toolkit ) ) {
				self::$instance = new Kalimdor_Toolkit;
				self::$instance->setup_constants();
				add_action( 'plugins_loaded', array( self::$instance, 'load_textdomain' ) );
				self::$instance->includes();
				add_action( 'after_setup_theme', array( self::$instance, 'after_setup_theme' ) );
			}

			return self::$instance;
		}

		public function after_setup_theme()
		{
			require_once KALIMDOR_TOOLKIT_PATH . 'includes/admin/import/import.php';
			require_once KALIMDOR_TOOLKIT_PATH . 'includes/admin/live-search/live-search.php';
            require_once KALIMDOR_TOOLKIT_PATH . 'includes/mapper/addon.php';
            if ( class_exists( 'WooCommerce' ) ) {
                require_once KALIMDOR_TOOLKIT_PATH . 'includes/dreaming-woocommerce-compare/dreaming-woocommerce-compare.php';
            }
		}

		public function setup_constants()
		{
			// Plugin version.
			if ( !defined( 'KALIMDOR_TOOLKIT_VERSION' ) ) {
				define( 'KALIMDOR_TOOLKIT_VERSION', '1.1.1' );
			}
			// Plugin Folder Path.
			if ( !defined( 'KALIMDOR_TOOLKIT_PATH' ) ) {
				define( 'KALIMDOR_TOOLKIT_PATH', plugin_dir_path( __FILE__ ) );
			}
			// Plugin Folder URL.
			if ( !defined( 'KALIMDOR_TOOLKIT_URL' ) ) {
				define( 'KALIMDOR_TOOLKIT_URL', plugin_dir_url( __FILE__ ) );
			}
		}

		public function includes()
		{
			require_once KALIMDOR_TOOLKIT_PATH . 'includes/admin/welcome.php';
			require_once KALIMDOR_TOOLKIT_PATH . 'includes/post-types.php';
            require_once KALIMDOR_TOOLKIT_PATH . 'includes/frontend/includes/shortcode.php';
			require_once KALIMDOR_TOOLKIT_PATH . 'includes/frontend/framework.php';
		}

		public function load_textdomain()
		{
			load_plugin_textdomain( 'kalimdor-toolkit', false, KALIMDOR_TOOLKIT_URL . 'languages' );
		}
	}
}
if ( !function_exists( 'KALIMDOR_TOOLKIT' ) ) {
	function KALIMDOR_TOOLKIT()
	{
		return Kalimdor_Toolkit::instance();
	}

	KALIMDOR_TOOLKIT();
	add_action( 'plugins_loaded', 'KALIMDOR_TOOLKIT', 10 );
}