<?php
/**
 * @version    1.0
 * @package    Teamo_Toolkit
 * @author     Teamo
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 */
/**
 * Class Toolkit Post Type
 *
 * @since    1.0
 */
if ( !class_exists( 'Teamo_Post_Type' ) ) {
	class Teamo_Post_Type
	{
		public function __construct()
		{
			add_action( 'init', array( &$this, 'init' ), 9999 );
		}

		public static function init()
		{
			/* Mega menu */
			$args = array(
				'labels'              => array(
					'name'               => __( 'Mega Builder', 'teamo-toolkit' ),
					'singular_name'      => __( 'Mega menu item', 'teamo-toolkit' ),
					'add_new'            => __( 'Add new', 'teamo-toolkit' ),
					'add_new_item'       => __( 'Add new menu item', 'teamo-toolkit' ),
					'edit_item'          => __( 'Edit menu item', 'teamo-toolkit' ),
					'new_item'           => __( 'New menu item', 'teamo-toolkit' ),
					'view_item'          => __( 'View menu item', 'teamo-toolkit' ),
					'search_items'       => __( 'Search menu items', 'teamo-toolkit' ),
					'not_found'          => __( 'No menu items found', 'teamo-toolkit' ),
					'not_found_in_trash' => __( 'No menu items found in trash', 'teamo-toolkit' ),
					'parent_item_colon'  => __( 'Parent menu item:', 'teamo-toolkit' ),
					'menu_name'          => __( 'Menu Builder', 'teamo-toolkit' ),
				),
				'hierarchical'        => false,
				'description'         => __( 'Mega Menus.', 'teamo-toolkit' ),
				'supports'            => array( 'title', 'editor' ),
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => 'teamo_menu',
				'menu_position'       => 3,
				'show_in_nav_menus'   => true,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'has_archive'         => false,
				'query_var'           => true,
				'can_export'          => true,
				'rewrite'             => false,
				'capability_type'     => 'page',
				'menu_icon'           => 'dashicons-welcome-widgets-menus',
			);
			register_post_type( 'megamenu', $args );
			/* Footer */
			$args = array(
				'labels'              => array(
					'name'               => __( 'Footers', 'teamo-toolkit' ),
					'singular_name'      => __( 'Footers', 'teamo-toolkit' ),
					'add_new'            => __( 'Add New', 'teamo-toolkit' ),
					'add_new_item'       => __( 'Add new footer', 'teamo-toolkit' ),
					'edit_item'          => __( 'Edit footer', 'teamo-toolkit' ),
					'new_item'           => __( 'New footer', 'teamo-toolkit' ),
					'view_item'          => __( 'View footer', 'teamo-toolkit' ),
					'search_items'       => __( 'Search template footer', 'teamo-toolkit' ),
					'not_found'          => __( 'No template items found', 'teamo-toolkit' ),
					'not_found_in_trash' => __( 'No template items found in trash', 'teamo-toolkit' ),
					'parent_item_colon'  => __( 'Parent template item:', 'teamo-toolkit' ),
					'menu_name'          => __( 'Footer Builder', 'teamo-toolkit' ),
				),
				'hierarchical'        => false,
				'description'         => __( 'To Build Template Footer.', 'teamo-toolkit' ),
				'supports'            => array( 'title', 'editor' ),
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => 'teamo_menu',
				'menu_position'       => 4,
				'show_in_nav_menus'   => true,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'has_archive'         => false,
				'query_var'           => true,
				'can_export'          => true,
				'rewrite'             => false,
				'capability_type'     => 'page',
			);
			register_post_type( 'footer', $args );
		}
	}

	new Teamo_Post_Type();
}
