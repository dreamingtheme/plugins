<?php
if ( ! class_exists( 'Teamo_Pinmap_Shortcode' ) ) {
	class Teamo_Pinmap_Shortcode {
		/**
		 * Initialize.
		 *
		 * @return  void
		 */
		public function __construct() {
			// Enqueue style and script
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
			// Add shortcode
			add_shortcode( 'teamo_pinmap', array( $this, 'render_shortcode' ) );
		}

		/**
		 * Enqueue custom scripts / stylesheets.
		 *
		 * @return  void
		 */
		public function enqueue_scripts() {
			// Enqueue Tooltip.
			wp_register_style( 'teamo-tooltip', TEAMO_TOOLKIT_URL . '/includes/mapper/assets/3rd-party/tooltip/tooltip.css', array(), '3.4.1' );
			wp_register_script( 'teamo-tooltip', TEAMO_TOOLKIT_URL . '/includes/mapper/assets/3rd-party/tooltip/tooltip.min.js', array(), '3.4.1', true );
			// Enqueue Awesome
			wp_register_style( 'font-awesome', TEAMO_TOOLKIT_URL . '/includes/mapper/assets/3rd-party/font-awesome/css/font-awesome.min.css', array(), '4.4.0' );
			// Enqueue assets for custom add/edit item form.
			wp_register_style( 'teamo-pinmap', TEAMO_TOOLKIT_URL . '/includes/mapper/assets/css/pinmap.css', array( 'teamo-tooltip' ), TEAMO_TOOLKIT_VERSION );
			wp_register_script( 'teamo-pinmap', TEAMO_TOOLKIT_URL . '/includes/mapper/assets/js/pinmap.js', array( 'teamo-tooltip' ), TEAMO_TOOLKIT_VERSION, true );
		}

		/**
		 * Render inline style.
		 *
		 * @param $attributes
		 * @param bool $echo
		 *
		 * @return mixed
		 */
		public function attribute( $attributes, $echo = true ) {
			$html = array();

			foreach ( $attributes as $key => $value ) {
				if ( is_bool( $value ) ) {
					if ( $value ) {
						$html[] = esc_attr( $key );
					}
					continue;
				}

				if ( $key === 'style' && is_array( $value ) ) {
					$style = array();
					foreach ( $value as $style_key => $style_value ) {
						$style[] = esc_attr( $style_key ) . ':' . esc_attr( $style_value );
					}
					$data = implode( ';', $style );
				} else {
					$data = is_array( $value ) ? implode( ' ', array_map( 'esc_attr', $value ) ) : esc_attr( $value );
				}

				$html[] = esc_attr( $key ) . '="' . $data . '"';
			}

			$output = implode( ' ', $html );

			if ( ! $echo ) {
				return $output;
			}

			echo wp_kses_post( $output );
		}

		public function content_image( $pin ) {
			$html = '';

			if ( $pin['settings']['popup-title'] ) {
				$html .= '<div class="teamo-popup-title">';
				$html .= '<h2>' . esc_html( $pin['settings']['popup-title'] ) . '</h2>';
				$html .= '</div>';
			}
			$html .= '<div class="content-image">';
			if ( ! empty( $pin['settings']['image-link-to'] ) ) {
				$html .= '<a target="' . esc_attr( $pin['settings']['image-link-target'] ) . '" href="' . esc_url( $pin['settings']['image-link-to'] ) . '">';
			}
			if ( $pin['settings']['image'] ) {
				$image_id = attachment_url_to_postid( $pin['settings']['image'] );
				if ( $image_id ) {
					$html .= wp_get_attachment_image( $image_id, 'full', false, [ 'alt' => $pin['settings']['popup-title'] ] );
				}
			}
			if ( ! empty( $pin['settings']['image-link-to'] ) ) {
				$html .= '</a>';
			}
			$html .= '</div>';

			return $html;
		}

		public function content_text( $pin ) {
			$html   = '';
			$link   = ! empty( $pin['settings']['image-link-to'] ) ? esc_url( $pin['settings']['image-link-to'] ) : '';
			$target = esc_attr( $pin['settings']['image-link-target'] );
			if ( $pin['settings']['popup-title'] ) {
				$html .= '<div class="teamo-popup-header">';
				$html .= '<h2>';
				if ( ! empty( $link ) ) {
					$html .= '<a class="teamo-link" target="' . $target . '" href="' . $link . '">' . esc_html( $pin['settings']['popup-title'] ) . '</a>';
				} else {
					$html .= esc_html( $pin['settings']['popup-title'] );
				}
				$html .= '</h2>';
				$html .= '</div>';
			}
			if ( $pin['settings']['text'] ) {
				$html .= '<div class="content-text">';
				$html .= do_shortcode( $pin['settings']['text'] );
				$html .= '</div>';
			}

			return $html;
		}

		public function content_link( $pin ) {
			$link   = ! empty( $pin['settings']['image-link-to'] ) ? esc_url( $pin['settings']['image-link-to'] ) : '#';
			$target = esc_attr( $pin['settings']['image-link-target'] );

			$html = '<a class="teamo-link" target="' . $target . '" href="' . $link . '"></a>';

			return wp_kses_post( $html );
		}

		public function content_woocommerce( $pin ) {
			if ( ! function_exists( 'wc_get_product' ) ) {
				return '';
			}

			$product_id = $pin['settings']['product'];
			$product    = wc_get_product( $product_id );

			ob_start();

			if ( ! empty( $product ) ) {
				$permalink     = apply_filters( 'woocommerce_loop_product_link', $product->get_permalink(), $product );
				if ( $pin['settings']['product-thumbnail'] ) :
					$image_size = apply_filters( 'teamo_pinmap_product_thumbnail', array(
						$pin['settings']['woo-width'],
						$pin['settings']['woo-height']
					) );
					$thumbnail = $product->get_image( $image_size );
					$thumbnail = apply_filters( 'teamo_pinmap_product_thumbnail_html', $thumbnail, $product, $pin );
					?>
                    <div class="col-left product-thumb">
                        <a href="<?php echo esc_url( $permalink ); ?>">
							<?php echo wp_kses_post( $thumbnail ); ?>
                        </a>
                    </div>
				<?php endif; ?>
                <div class="col-right product-info">
                    <h2 class="product-name product_title">
                        <a href="<?php echo esc_url( $permalink ); ?>">
							<?php echo esc_html( $product->get_name() ); ?>
                        </a>
                    </h2>
					<?php if ( $pin['settings']['product-rate'] ) {
						echo wp_kses_post( wc_get_rating_html( $product->get_average_rating() ) );
					} ?>
                    <div class="price">
						<?php echo wp_kses_post( $product->get_price_html() ); ?>
                    </div>
					<?php if ( $pin['settings']['product-description'] ) { ?>
                        <div class="description">
							<?php echo wp_kses_post( wp_trim_words( $product->get_short_description(), 10, '...' ) ); ?>
                        </div>
					<?php } ?>
                </div>
				<?php
			}

			wp_reset_postdata();

			return ob_get_clean();
		}

		public function popup_before( $pin ) {
			$popup_attr = array(
				'class' => array(
					'teamo-popup',
					'popup-' . $pin['settings']['pin-type'],
					$pin['settings']['popup-position'],
				)
			);
			?>
            <div class="teamo-popup-tooltip">
            <div <?php $this->attribute( $popup_attr ); ?>>
            <div class="teamo-popup-main">
			<?php
		}

		public function popup_after( $pin ) {
			?>
            </div>
            </div>
            </div>
			<?php
		}

		/**
		 * Generate HTML code based on shortcode parameters.
		 *
		 * @param array $atts Shortcode parameters.
		 * @param string $content Current content.
		 *
		 * @return mixed|string|void $html
		 */
		public function render_shortcode( $atts, $content = null ) {
			// Extract shortcode parameters.
			if ( ! isset( $atts['id'] ) ) {
				return '';
			}
			// Check is publish
			if ( get_post_status( $atts['id'] ) != 'publish' ) {
				return '';
			}
			// Get current image.
			$attachment_id = get_post_meta( $atts['id'], 'teamo_pinmap_image', true );
			if ( ! $attachment_id ) {
				return '';
			}
			// Get content source.
			$content_builder = apply_filters( 'the_content', get_post_field( 'post_content', $atts['id'] ) );
			$content_builder = str_replace( ']]>', ']]>', $content_builder );
			// Get image source.
			$image_data = wp_get_attachment_metadata( $attachment_id );
			// Get general settings.
			$settings = get_post_meta( $atts['id'], 'teamo_pinmap_settings', true );
			// Get all pins.
			$pins = get_post_meta( $atts['id'], 'teamo_pinmap_pins', true );
			// Check is empty
			if ( empty( $pins ) ) {
				return '';
			}
			// Enqueue required assets.
			wp_enqueue_style( 'font-awesome' );
			wp_enqueue_style( 'teamo-pinmap' );
			wp_enqueue_script( 'teamo-pinmap' );

			add_action( 'wp_footer', function () use ( $atts, $settings, $pins ) {
				$css = $this->inline_style( $atts['id'], $settings, $pins );

				if ( ! empty( $css ) ) {
					echo '<style>' . esc_html( $css ) . '</style>';
				}
			} );
			// Generate HTML.
			$id_shortcode = 'shortcode-pinmap-' . $atts['id'];
			$pinmap_attr  = array(
				'id'          => 'teamo-pinmap-' . $atts['id'],
				'class'       => array(
					'teamo-pinmap',
					$settings['image-effect'],
					$settings['tooltip-style'],
					$settings['popup-show-effect'],
				),
				'data-width'  => $image_data['width'],
				'data-height' => $image_data['height'],
			);
			ob_start();
			?>
            <div id="<?php echo esc_attr( $id_shortcode ); ?>" class="shortcode-pinmap-builder">
                <div <?php $this->attribute( $pinmap_attr ); ?>>
                    <div class="wrap-image"><?php echo wp_get_attachment_image( $attachment_id, 'full' ); ?></div>
					<?php if ( $settings['image-effect'] == 'mask' ): ?>
                        <div class="mask"></div>
					<?php endif; ?>
					<?php if ( ! Teamo_Pinmap_Post_Type::is_elementor_editor() ): ?>
						<?php foreach ( $pins as $index => $pin ) :
							$pin_attr = array(
								'id'            => 'teamo-pin-' . $pin['settings']['id'],
								'class'         => array(
									'teamo-pin',
									$pin['settings']['pin-type'],
									'position-' . $pin['settings']['popup-position'],
								),
								'data-top'      => $pin['top'],
								'data-left'     => $pin['left'],
								'data-trigger'  => $settings['popup-trigger'],
								'data-position' => $pin['settings']['popup-position'],
							);
							if ( $pin['settings']['pin-type'] == 'text' ) {
								$pin_attr['class'][] = $pin['settings']['text-style'];
							}
							$method = "content_{$pin['settings']['pin-type']}";
							?>
                            <div <?php $this->attribute( $pin_attr ); ?>>
								<?php
								if ( $pin['settings']['icon-type'] == 'icon-image' && ! empty( $pin['settings']['image-template'] ) ) {
									$image_url = $pin['settings']['image-template'];
									$image_id  = attachment_url_to_postid( $image_url );
									echo '<a href="javascript:void(0)" class="action-pin image-pin" tabindex="' . esc_attr( $index ) . '">';
									if ( $image_id ) {
										echo wp_get_attachment_image( $image_id, 'full', false, [ 'alt' => 'Pin' ] );
									}
									echo '</a>';
								} else {
									echo '<div class="action-pin text__area ' . esc_attr( $pin['settings']['icon-type'] ) . '" tabindex="' . esc_attr( $index ) . '">';
									if ( ! empty( $pin['settings']['area-text'] ) ) {
										echo wp_kses_post( $pin['settings']['area-text'] );
									}
									echo '</div>';
								}
								if ( method_exists( $this, $method ) ) {

									$this->popup_before( $pin );

									echo wp_kses_post( apply_filters( 'teamo_content_type_pinmap', $this->$method( $pin ), $atts, $this ) );

									$this->popup_after( $pin );
								}
								?>
                            </div>
						<?php endforeach; ?>
					<?php endif; ?>
                </div>
				<?php
				if ( $content_builder ) {
					echo '<div class="content-builder"><div class="container">' . wp_kses_post( $content_builder ) . '</div></div>';
				}
				?>
            </div>
			<?php

			return apply_filters( 'teamo_render_shortcode_pinmap', ob_get_clean(), $atts );
		}

		/**
		 * Render inline style.
		 *
		 * @param int $id Mapper ID.
		 * @param array $settings Mapper settings.
		 * @param array $pins Mapper pins.
		 *
		 * @return string|string[]|null $css
		 */
		public function inline_style( $id, $settings, $pins ) {
			$css = '';
			// Generate CSS rules for general settings.
			$css .= '#TEAMOpopover' . $id . ' .teamo-popup {';
			$css .= 'padding: 10px;';
			if ( $settings['popup-width'] ) {
				$css .= 'width: ' . esc_attr( $settings['popup-width'] ) . 'px;';
			}
			if ( $settings['popup-height'] ) {
				$css .= 'min-height: ' . esc_attr( $settings['popup-height'] ) . 'px;';
			}
			if ( $settings['popup-box-shadow'] ) {
				$css .= 'box-shadow: 0px 2px 10px 0px ' . esc_attr( $settings['popup-box-shadow'] ) . ';';
			}
			if ( $settings['popup-border-radius'] ) {
				$css .= 'border-radius: ' . (int) $settings['popup-border-radius'] . 'px;';
			}
			if ( $settings['popup-border-width'] ) {
				$css .= 'border: ' . (int) $settings['popup-border-width'] . 'px solid;';
			}
			if ( $settings['popup-border-color'] ) {
				$css .= 'border-color: ' . esc_attr( $settings['popup-border-color'] ) . ';';
			}
			$css .= '}';
			if ( $settings['image-effect'] == 'mask' ) {
				$css .= '
				#teamo-pinmap-' . $id . ' .mask {';
				if ( $settings['mask-color'] ) {
					$css .= 'background: ' . esc_attr( $settings['mask-color'] ) . ';';
				}
				$css .= '}';
			}
			// Generate CSS rules for each pin.
			if ( $pins ) {
				foreach ( $pins as $pin ) {
					// Popup width & height
					$css .= '
					#teamo-pinmap-' . $id . ' #teamo-pin-' . esc_attr( $pin['settings']['id'] ) . ' .teamo-popup {';
					if ( isset( $pin['settings']['popup-width'] ) && (int) $pin['settings']['popup-width'] > 0 ) {
						$css .= 'width: ' . (int) esc_attr( $pin['settings']['popup-width'] ) . 'px;';
					}
					if ( isset( $pin['settings']['popup-height'] ) && (int) $pin['settings']['popup-height'] > 0 ) {
						$css .= 'min-height: ' . (int) esc_attr( $pin['settings']['popup-height'] ) . 'px;';
					}
					$css .= '}';
					// Pin style setting
					$css .= '
					#teamo-pinmap-' . $id . ' #teamo-pin-' . esc_attr( $pin['settings']['id'] ) . ' .icon-pin {';
					if ( isset( $pin['settings']['bg-color'] ) ) {
						$css .= 'background: ' . esc_attr( $pin['settings']['bg-color'] ) . ';';
					}
					if ( isset( $pin['settings']['icon-color'] ) ) {
						$css .= 'color: ' . esc_attr( $pin['settings']['icon-color'] ) . ';';
					}
					if ( isset( $pin['settings']['icon-size'] ) ) {
						$css .= 'font-size: ' . (int) esc_attr( $pin['settings']['icon-size'] ) . 'px;';
						$css .= 'width: ' . (int) esc_attr( $pin['settings']['icon-size'] ) * 1.2 . 'px;';
						$css .= 'line-height: ' . (int) esc_attr( $pin['settings']['icon-size'] ) * 1.2 . 'px;';
					}
					if ( isset( $pin['settings']['border-width'] ) && (int) $pin['settings']['border-width'] > 0 ) {
						$css .= 'box-shadow: 0 0 0 ' . (int) esc_attr( $pin['settings']['border-width'] ) . 'px ' . esc_attr( $pin['settings']['border-color'] ) . ';';
					}
					$css .= '}';
					// Pin hover setting
					$css .= '
					#teamo-pinmap-' . $id . ' #teamo-pin-' . esc_attr( $pin['settings']['id'] ) . ' .icon-pin:hover {';
					if ( isset( $pin['settings']['bg-color-hover'] ) ) {
						$css .= 'background: ' . esc_attr( $pin['settings']['bg-color-hover'] ) . ';';
					}
					if ( isset( $pin['settings']['icon-color-hover'] ) ) {
						$css .= 'color: ' . esc_attr( $pin['settings']['icon-color-hover'] ) . ';';
					}
					$css .= '}';
					// Style text
					if ( $pin['settings']['icon-type'] == 'icon-area' ) {
						$css .= '
					    #teamo-pinmap-' . $id . ' #teamo-pin-' . esc_attr( $pin['settings']['id'] ) . ' .text__area{';
						$css .= 'line-height: ' . (int) esc_attr( $pin['settings']['area-text-line-height'] ) . 'px;';
						$css .= 'font-size: ' . (int) esc_attr( $pin['settings']['area-text-size'] ) . 'px;';
						$css .= 'color: ' . esc_attr( $pin['settings']['area-text-color'] ) . ';';
						$css .= 'width: ' . (int) esc_attr( $pin['settings']['area-width'] ) . 'px;';
						$css .= 'height: ' . (int) esc_attr( $pin['settings']['area-height'] ) . 'px;';
						$css .= 'border-width: ' . (int) esc_attr( $pin['settings']['area-border-width'] ) . 'px;';
						$css .= 'border-radius: ' . (int) esc_attr( $pin['settings']['area-border-radius'] ) . 'px;';
						$css .= 'border-color: ' . esc_attr( $pin['settings']['area-border-color'] ) . ';';
						$css .= 'border-style: solid;';
						$css .= 'background: ' . esc_attr( $pin['settings']['area-bg-color'] ) . ';';
						$css .= '}';
						// Hover text
						$css .= '
                	    #teamo-pinmap-' . $id . ' #teamo-pin-' . esc_attr( $pin['settings']['id'] ) . ' .text__area:hover,
                 	    #teamo-pinmap-' . $id . ' #teamo-pin-' . esc_attr( $pin['settings']['id'] ) . ' img:hover{ ';
						$css .= '}';
					}
				}
			}

			return preg_replace( '/\s+/', ' ', $css );
		}
	}

	new Teamo_Pinmap_Shortcode();
}
