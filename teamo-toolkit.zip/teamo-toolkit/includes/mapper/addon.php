<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'Teamo_Pinmap_Builder' ) ) {
	class  Teamo_Pinmap_Builder
	{
		/**
		 * @var Teamo_Pinmap_Builder The one true Teamo_Pinmap_Builder
		 */
		private static $instance;

		public static function instance()
		{
			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Teamo_Pinmap_Builder ) ) {
				self::$instance = new Teamo_Pinmap_Builder;
				self::$instance->includes();
				/* Add image size for woocommerce product */
				$size_thumb = apply_filters( 'teamo_pinmap_product_thumbnail', array(
						'width'  => 100,
						'height' => 150,
						'crop'   => true
					)
				);
				add_image_size( 'teamo-pinmap-thumbnail', $size_thumb['width'], $size_thumb['height'], $size_thumb['crop'] );
			}

			return self::$instance;
		}

		public function includes()
		{
			require_once TEAMO_TOOLKIT_PATH . 'includes/mapper/includes/post-type.php';
			require_once TEAMO_TOOLKIT_PATH . 'includes/mapper/includes/shortcode.php';
		}
	}
}
if ( ! function_exists( 'Teamo_Pinmap_Builder' ) ) {
	function Teamo_Pinmap_Builder()
	{
		return Teamo_Pinmap_Builder::instance();
	}
}
Teamo_Pinmap_Builder();