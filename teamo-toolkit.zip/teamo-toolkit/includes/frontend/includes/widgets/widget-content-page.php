<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Teamo Content Page
 *
 * Displays Content Page widget.
 *
 * @category Widgets
 * @package  Teamo/Widgets
 * @version  1.0.0
 * @extends  TEAMO_Widget
 */
if ( !class_exists( 'Teamo_Content_Page_Widget' ) ) {
	class Teamo_Content_Page_Widget extends TEAMO_Widget
	{
		/**
		 * Constructor.
		 */
		public function __construct()
		{
			$array_settings           = apply_filters( 'teamo_filter_settings_widget_content_page',
				array(
					'title'         => array(
						'type'  => 'text',
						'title' => esc_html__( 'Title', 'teamo-toolkit' ),
					),
					'teamo_page_id' => array(
						'type'    => 'select',
						'title'   => esc_html__( 'Select Content', 'teamo-toolkit' ),
						'options' => 'pages',
					),
				)
			);
			$this->widget_cssclass    = 'widget-teamo-content_page teamo-content_page';
			$this->widget_description = esc_html__( 'Display the customer Content Page.', 'teamo-toolkit' );
			$this->widget_id          = 'widget_teamo_content_page';
			$this->widget_name        = esc_html__( 'Teamo: Content Page', 'teamo-toolkit' );
			$this->settings           = $array_settings;
			parent::__construct();
		}

		/**
		 * Output widget.
		 *
		 * @see WP_Widget
		 *
		 * @param array $args
		 * @param array $instance
		 */
		public function widget( $args, $instance )
		{
			$this->widget_start( $args, $instance );
			if ( $instance['teamo_page_id'] ) {
				$post_id = get_post( $instance['teamo_page_id'] );
				$content = $post_id->post_content;
				$content = apply_filters( 'the_content', $content );
				$content = str_replace( ']]>', ']]>', $content );
				/* GET CUSTOM CSS */
				$post_custom_css = get_post_meta( $instance['teamo_page_id'], '_Teamo_Shortcode_custom_css', true );
				echo '<style type="text/css">' . $post_custom_css . '</style>';
				echo $content;
			}
			$this->widget_end( $args );
		}
	}
}
/**
 * Register Widgets.
 *
 * @since 2.3.0
 */
function Teamo_Content_Page_Widget()
{
	register_widget( 'Teamo_Content_Page_Widget' );
}

add_action( 'widgets_init', 'Teamo_Content_Page_Widget' );