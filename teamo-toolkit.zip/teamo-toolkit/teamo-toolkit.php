<?php
/**
 * Plugin Name: Teamo Toolkit
 * Plugin URI: https://dreamingtheme.great-site.net/
 * Description: The Teamo Toolkit For WordPress Theme WooCommerce Shop.
 * Author: Dreamingtheme
 * Author URI: https://dreamingtheme.great-site.net/
 * Version: 1.0.3
 * Text Domain: teamo-toolkit
 */
// Exit if accessed directly.
if ( !defined( 'ABSPATH' ) ) exit;
if ( !class_exists( 'Teamo_Toolkit' ) ) {
	class  Teamo_Toolkit
	{
		/**
		 * @var Teamo_Toolkit The one true Teamo_Toolkit
		 * @since 1.0
		 */
		private static $instance;

		public static function instance()
		{
			if ( !isset( self::$instance ) && !( self::$instance instanceof Teamo_Toolkit ) ) {
				self::$instance = new Teamo_Toolkit;
				self::$instance->setup_constants();
				add_action( 'init', array( self::$instance, 'load_textdomain' ) );
				self::$instance->includes();
				add_action( 'after_setup_theme', array( self::$instance, 'after_setup_theme' ) );
                add_action('upload_mimes', array(self::$instance, 'teamo_toolkit_add_file_types_to_uploads'));
			}

			return self::$instance;
		}

		public function after_setup_theme()
		{
			require_once TEAMO_TOOLKIT_PATH . 'includes/admin/import/import.php';
			require_once TEAMO_TOOLKIT_PATH . 'includes/admin/live-search/live-search.php';
			require_once TEAMO_TOOLKIT_PATH . 'includes/mapper/addon.php';
            if ( class_exists( 'WooCommerce' ) ) {
                require_once TEAMO_TOOLKIT_PATH . 'includes/dreaming-woocommerce-compare/dreaming-woocommerce-compare.php';
            }
		}

		public function setup_constants()
		{
			// Plugin version.
			if ( !defined( 'TEAMO_TOOLKIT_VERSION' ) ) {
				define( 'TEAMO_TOOLKIT_VERSION', '1.0.2' );
			}
			// Plugin Folder Path.
			if ( !defined( 'TEAMO_TOOLKIT_PATH' ) ) {
				define( 'TEAMO_TOOLKIT_PATH', plugin_dir_path( __FILE__ ) );
			}
			// Plugin Folder URL.
			if ( !defined( 'TEAMO_TOOLKIT_URL' ) ) {
				define( 'TEAMO_TOOLKIT_URL', plugin_dir_url( __FILE__ ) );
			}
		}

		public function includes()
		{
			require_once TEAMO_TOOLKIT_PATH . 'includes/admin/welcome.php';
			require_once TEAMO_TOOLKIT_PATH . 'includes/post-types.php';
            require_once TEAMO_TOOLKIT_PATH . 'includes/frontend/includes/shortcode.php';
			require_once TEAMO_TOOLKIT_PATH . 'includes/frontend/framework.php';
		}

		public function load_textdomain()
		{
			load_plugin_textdomain( 'teamo-toolkit', false, TEAMO_TOOLKIT_URL . 'languages' );
		}

        function teamo_toolkit_add_file_types_to_uploads($file_types)
        {
            $new_filetypes = array();
            $new_filetypes['svg'] = 'image/svg+xml';
            $file_types = array_merge($file_types, $new_filetypes);

            return $file_types;
        }
	}
}
if ( !function_exists( 'TEAMO_TOOLKIT' ) ) {
	function TEAMO_TOOLKIT()
	{
		return Teamo_Toolkit::instance();
	}

	TEAMO_TOOLKIT();
	add_action( 'plugins_loaded', 'TEAMO_TOOLKIT', 10 );
}