<?php
/**
 * Plugin Name: Azeroth Toolkit
 * Plugin URI: https://dreamingtheme.great-site.net/
 * Description: The Azeroth Toolkit For WordPress Theme WooCommerce Shop.
 * Author: Dreamingtheme
 * Author URI: https://dreamingtheme.great-site.net/
 * Version: 1.1.1
 * Text Domain: azeroth-toolkit
 */
// Exit if accessed directly.
if ( !defined( 'ABSPATH' ) ) exit;
if ( !class_exists( 'Azeroth_Toolkit' ) ) {
	class  Azeroth_Toolkit
	{
		/**
		 * @var Azeroth_Toolkit The one true Azeroth_Toolkit
		 * @since 1.0
		 */
		private static $instance;

		public static function instance()
		{
			if ( !isset( self::$instance ) && !( self::$instance instanceof Azeroth_Toolkit ) ) {
				self::$instance = new Azeroth_Toolkit;
				self::$instance->setup_constants();
				add_action( 'plugins_loaded', array( self::$instance, 'load_textdomain' ) );
				self::$instance->includes();
				add_action( 'after_setup_theme', array( self::$instance, 'after_setup_theme' ) );
			}

			return self::$instance;
		}

		public function after_setup_theme()
		{
			require_once AZEROTH_TOOLKIT_PATH . 'includes/admin/import/import.php';
			require_once AZEROTH_TOOLKIT_PATH . 'includes/admin/live-search/live-search.php';
			require_once AZEROTH_TOOLKIT_PATH . 'includes/mapper/addon.php';
            if ( class_exists( 'WooCommerce' ) ) {
                require_once AZEROTH_TOOLKIT_PATH . 'includes/dreaming-woocommerce-compare/dreaming-woocommerce-compare.php';
            }
		}

		public function setup_constants()
		{
			// Plugin version.
			if ( !defined( 'AZEROTH_TOOLKIT_VERSION' ) ) {
				define( 'AZEROTH_TOOLKIT_VERSION', '1.1.0' );
			}
			// Plugin Folder Path.
			if ( !defined( 'AZEROTH_TOOLKIT_PATH' ) ) {
				define( 'AZEROTH_TOOLKIT_PATH', plugin_dir_path( __FILE__ ) );
			}
			// Plugin Folder URL.
			if ( !defined( 'AZEROTH_TOOLKIT_URL' ) ) {
				define( 'AZEROTH_TOOLKIT_URL', plugin_dir_url( __FILE__ ) );
			}
		}

		public function includes()
		{
			require_once AZEROTH_TOOLKIT_PATH . 'includes/admin/welcome.php';
            require_once AZEROTH_TOOLKIT_PATH . 'includes/frontend/includes/shortcode.php';
			require_once AZEROTH_TOOLKIT_PATH . 'includes/frontend/framework.php';
		}

		public function load_textdomain()
		{
			load_plugin_textdomain( 'azeroth-toolkit', false, AZEROTH_TOOLKIT_URL . 'languages' );
		}
	}
}
if ( !function_exists( 'AZEROTH_TOOLKIT' ) ) {
	function AZEROTH_TOOLKIT()
	{
		return Azeroth_Toolkit::instance();
	}

	AZEROTH_TOOLKIT();
	add_action( 'plugins_loaded', 'AZEROTH_TOOLKIT', 10 );
}
//check load mobile
if ( !function_exists( 'azeroth_toolkit_is_mobile' ) ) {
	function azeroth_toolkit_is_mobile() {
		if ( empty( $_SERVER['HTTP_USER_AGENT'] ) ) {
			$is_mobile = false;
		} elseif ( strpos( $_SERVER['HTTP_USER_AGENT'], 'Mobile' ) !== false // many mobile devices (all iPhone, iPad, etc.)
		           || strpos( $_SERVER['HTTP_USER_AGENT'], 'Android' ) !== false
		           || strpos( $_SERVER['HTTP_USER_AGENT'], 'Silk/' ) !== false
		           || strpos( $_SERVER['HTTP_USER_AGENT'], 'Kindle' ) !== false
		           || strpos( $_SERVER['HTTP_USER_AGENT'], 'BlackBerry' ) !== false
		           || strpos( $_SERVER['HTTP_USER_AGENT'], 'Opera Mini' ) !== false
		           || strpos( $_SERVER['HTTP_USER_AGENT'], 'Opera Mobi' ) !== false ) {
			$is_mobile = true;
		} else {
			$is_mobile = false;
		}
		
		return apply_filters( 'wp_is_mobile', $is_mobile );
	}
}