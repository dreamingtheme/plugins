<?php
/**
 * Azeroth Megamenu Builder setup
 *
 * @author   FAMI
 * @category API
 * @package  Azeroth_Megamenu_Builder
 * @since    1.0.0
 */
if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * Azeroth Megamenu Builder setup
 *
 * @Active: add_theme_support( 'azeroth-megamenu-builder' );
 */
if ( !class_exists( 'Azeroth_Megamenu_Builder' ) ) {
	class Azeroth_Megamenu_Builder
	{
		public function __construct()
		{
			add_action( 'init', array( &$this, 'post_type' ), 10 );
			add_action( 'wp_megamenu', array( $this, 'azeroth_megamenu_content' ) );
			add_filter( 'azeroth_main_custom_css', array( $this, 'azeroth_shortcodes_custom_css' ) );
		}

		function azeroth_megamenu_content()
		{
            $data_meta           = get_post_meta( get_the_ID(), '_custom_metabox_theme_options', true );
            $megamenu_options      = ( class_exists( 'Azeroth_Functions' ) ) ? Azeroth_Functions::azeroth_get_option( 'megamenu_options' ) : cs_get_option( 'megamenu_options', '' );
            $megamenu_options      = isset( $data_meta['enable_megamenu'] ) && $data_meta['enable_megamenu'] == 1 && isset( $data_meta['metabox_megamenu_options'] ) && $data_meta['metabox_megamenu_options'] != '' ? $data_meta['metabox_megamenu_options'] : $megamenu_options;
			$class = array( 'megamenu', 'azeroth-megamenu' );
			$args  = array(
				'post_type'      => 'megamenu',
				'posts_per_page' => 1,
			);
			if ( $megamenu_options ) {
				$args['p'] = $megamenu_options;
			}
			$query = new WP_Query( $args );
			if ( $query->have_posts() ) {
				$class[] = 'empty-megamenu';
			}
			ob_start(); ?>
            <megamenu id ="megamenu" class="<?php echo esc_attr( implode( ' ', $class ) ); ?>">
				<?php if ( $query->have_posts() ): ?>
					<?php while ( $query->have_posts() ): $query->the_post();
						$post_id = get_post( get_the_ID() );
						$content = $post_id->post_content;
						$content = apply_filters( 'the_content', $content );
						$content = str_replace( ']]>', ']]>', $content );
						echo '<div class="container">' . wp_specialchars_decode( $content ) . '</div>';
					endwhile;
					wp_reset_postdata(); ?>
				<?php endif; ?>
            </megamenu>
			<?php echo apply_filters( 'azeroth_filter_content_megamenu', ob_get_clean(), $class );
		}

		function azeroth_shortcodes_custom_css( $css )
		{
			$args = array(
				'post_type'      => 'megamenu',
				'posts_per_page' => -1,
			);
			$loop = new WP_Query( $args );
			while ( $loop->have_posts() ) : $loop->the_post();
				$post_custom_css   = array();
				$post_custom_css[] = get_post_meta( get_the_ID(), '_wpb_post_custom_css', true );
				$post_custom_css[] = get_post_meta( get_the_ID(), '_Azeroth_Shortcode_custom_css', true );
				if ( count( $post_custom_css ) > 0 ) {
					$css .= implode( ' ', $post_custom_css );
				}
			endwhile;
			wp_reset_postdata();

			return $css;
		}

		function post_type()
		{
			/* Megamenu */
			$args = array(
				'labels'              => array(
					'name'               => __( 'Megamenu', 'azeroth-toolkit' ),
					'singular_name'      => __( 'Megamenu', 'azeroth-toolkit' ),
					'add_new'            => __( 'Add New', 'azeroth-toolkit' ),
					'add_new_item'       => __( 'Add new megamenu', 'azeroth-toolkit' ),
					'edit_item'          => __( 'Edit megamenu', 'azeroth-toolkit' ),
					'new_item'           => __( 'New megamenu', 'azeroth-toolkit' ),
					'view_item'          => __( 'View megamenu', 'azeroth-toolkit' ),
					'search_items'       => __( 'Search template megamenu', 'azeroth-toolkit' ),
					'not_found'          => __( 'No template items found', 'azeroth-toolkit' ),
					'not_found_in_trash' => __( 'No template items found in trash', 'azeroth-toolkit' ),
					'parent_item_colon'  => __( 'Parent template item:', 'azeroth-toolkit' ),
					'menu_name'          => __( 'Megamenu Builder', 'azeroth-toolkit' ),
				),
				'hierarchical'        => false,
				'description'         => __( 'To Build Template Megamenu.', 'azeroth-toolkit' ),
				'supports'            => array(
					'title',
					'editor',
					'thumbnail',
					'revisions',
				),
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => 'azeroth_menu',
				'menu_position'       => 4,
				'show_in_nav_menus'   => true,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'has_archive'         => false,
				'query_var'           => true,
				'can_export'          => true,
				'rewrite'             => false,
				'capability_type'     => 'page',
			);
			register_post_type( 'megamenu', $args );
		}
	}

	new Azeroth_Megamenu_Builder();
}