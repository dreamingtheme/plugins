<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Azeroth Content Page
 *
 * Displays Content Page widget.
 *
 * @category Widgets
 * @package  Azeroth/Widgets
 * @version  1.0.0
 * @extends  AZEROTH_Widget
 */
if ( !class_exists( 'Azeroth_Content_Page_Widget' ) ) {
	class Azeroth_Content_Page_Widget extends AZEROTH_Widget
	{
		/**
		 * Constructor.
		 */
		public function __construct()
		{
			$array_settings           = apply_filters( 'azeroth_filter_settings_widget_content_page',
				array(
					'title'         => array(
						'type'  => 'text',
						'title' => esc_html__( 'Title', 'azeroth-toolkit' ),
					),
					'azeroth_page_id' => array(
						'type'    => 'select',
						'title'   => esc_html__( 'Select Content', 'azeroth-toolkit' ),
						'options' => 'pages',
					),
				)
			);
			$this->widget_cssclass    = 'widget-azeroth-content_page azeroth-content_page';
			$this->widget_description = esc_html__( 'Display the customer Content Page.', 'azeroth-toolkit' );
			$this->widget_id          = 'widget_azeroth_content_page';
			$this->widget_name        = esc_html__( 'Azeroth: Content Page', 'azeroth-toolkit' );
			$this->settings           = $array_settings;
			parent::__construct();
		}

		/**
		 * Output widget.
		 *
		 * @see WP_Widget
		 *
		 * @param array $args
		 * @param array $instance
		 */
		public function widget( $args, $instance )
		{
			$this->widget_start( $args, $instance );
			if ( $instance['azeroth_page_id'] ) {
				$post_id = get_post( $instance['azeroth_page_id'] );
				$content = $post_id->post_content;
				$content = apply_filters( 'the_content', $content );
				$content = str_replace( ']]>', ']]>', $content );
				/* GET CUSTOM CSS */
				$post_custom_css = get_post_meta( $instance['azeroth_page_id'], '_Azeroth_Shortcode_custom_css', true );
				echo '<style type="text/css">' . $post_custom_css . '</style>';
				echo $content;
			}
			$this->widget_end( $args );
		}
	}
}
/**
 * Register Widgets.
 *
 * @since 2.3.0
 */
function Azeroth_Content_Page_Widget()
{
	register_widget( 'Azeroth_Content_Page_Widget' );
}

add_action( 'widgets_init', 'Azeroth_Content_Page_Widget' );