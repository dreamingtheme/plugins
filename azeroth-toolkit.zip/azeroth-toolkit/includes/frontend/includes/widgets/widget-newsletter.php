<?php
if (!defined('ABSPATH')) {
    exit;
}
/**
 * Azeroth Mailchimp
 *
 * Displays Mailchimp widget.
 *
 * @category Widgets
 * @package  Azeroth/Widgets
 * @version  1.0.0
 * @extends  AZEROTH_Widget
 */
if (!class_exists('Azeroth_Mailchimp_Widget')) {
    class Azeroth_Mailchimp_Widget extends AZEROTH_Widget
    {
        /**
         * Constructor.
         */
        public function __construct()
        {
            $array_settings = apply_filters('azeroth_filter_settings_widget_mailchimp',
                array(
                    'title' => array(
                        'type' => 'text',
                        'title' => esc_html__('Title', 'azeroth-toolkit'),
                    ),
                    'description' => array(
                        'type' => 'text',
                        'title' => esc_html__('Description:', 'azeroth-toolkit'),
                        'default' => esc_html__('To stay up-to-date on our promotions, discounts, sales and more', 'azeroth-toolkit'),
                    ),
                    'placeholder' => array(
                        'type' => 'text',
                        'title' => esc_html__('Placeholder Text:', 'azeroth-toolkit'),
                        'default' => esc_html__('Enter your email address', 'azeroth-toolkit'),
                    ),
                )
            );
            $this->widget_cssclass = 'widget-azeroth-mailchimp';
            $this->widget_description = esc_html__('Display the customer Newsletter.', 'azeroth-toolkit');
            $this->widget_id = 'widget_azeroth_mailchimp';
            $this->widget_name = esc_html__('Azeroth: Newsletter', 'azeroth-toolkit');
            $this->settings = $array_settings;
            parent::__construct();
        }

        /**
         * Output widget.
         *
         * @see WP_Widget
         *
         * @param array $args
         * @param array $instance
         */
        public function widget($args, $instance)
        {
            $this->widget_start($args, $instance);
            ob_start();
            ?>
            <div class="newsletter-form-wrap">
                <div class="desc"><?php echo esc_html($instance['description']); ?></div>
                <div class="form-newsletter">
                    <input class="email email-newsletter" type="email" name="email"
                           placeholder="<?php echo esc_attr($instance['placeholder']); ?>">
                    <a href="#" class="button btn-submit submit-newsletter">
                        <?php echo esc_html__('SUBSCRIBE', 'azeroth-toolkit') ?></span>
                    </a>
                </div>
            </div>
            <?php
            echo apply_filters('azeroth_filter_widget_newsletter', ob_get_clean(), $instance);
            $this->widget_end($args);
        }
    }
}
add_action('widgets_init', 'Azeroth_Mailchimp_Widget');
if (!function_exists('Azeroth_Mailchimp_Widget')) {
    function Azeroth_Mailchimp_Widget()
    {
        register_widget('Azeroth_Mailchimp_Widget');
    }
}