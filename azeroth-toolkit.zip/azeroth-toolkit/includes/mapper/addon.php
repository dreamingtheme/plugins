<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'Azeroth_Pinmap_Builder' ) ) {
	class  Azeroth_Pinmap_Builder
	{
		/**
		 * @var Azeroth_Pinmap_Builder The one true Azeroth_Pinmap_Builder
		 */
		private static $instance;

		public static function instance()
		{
			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Azeroth_Pinmap_Builder ) ) {
				self::$instance = new Azeroth_Pinmap_Builder;
				self::$instance->includes();
				/* Add image size for woocommerce product */
				$size_thumb = apply_filters( 'azeroth_pinmap_product_thumbnail', array(
						'width'  => 100,
						'height' => 150,
						'crop'   => true
					)
				);
				add_image_size( 'azeroth-pinmap-thumbnail', $size_thumb['width'], $size_thumb['height'], $size_thumb['crop'] );
			}

			return self::$instance;
		}

		public function includes()
		{
			require_once AZEROTH_TOOLKIT_PATH . 'includes/mapper/includes/post-type.php';
			require_once AZEROTH_TOOLKIT_PATH . 'includes/mapper/includes/shortcode.php';
		}
	}
}
if ( ! function_exists( 'Azeroth_Pinmap_Builder' ) ) {
	function Azeroth_Pinmap_Builder()
	{
		return Azeroth_Pinmap_Builder::instance();
	}
}
Azeroth_Pinmap_Builder();